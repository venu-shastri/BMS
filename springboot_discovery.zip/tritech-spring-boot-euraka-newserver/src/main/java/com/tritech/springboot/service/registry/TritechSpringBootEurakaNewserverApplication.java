package com.tritech.springboot.service.registry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;


@SpringBootApplication
@EnableEurekaServer
public class TritechSpringBootEurakaNewserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(TritechSpringBootEurakaNewserverApplication.class, args);
	}

}
