package com.tritech.springboot.service.registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TritechSpringBootEurakaNewserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
