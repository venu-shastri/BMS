package com.tritech.springboot.service.discovery.client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RibbonClient("tritech-spring-boot-service-discovery-client")
@RestController
public class ClientController {
	@LoadBalanced
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Autowired
	private RestTemplate restTemplate;

	@RequestMapping("/service")

	public String getTest() {
		
		String result = restTemplate.getForObject("http://test-service-one/test", String.class);
		
		
		return result;
	}
	
	public String getTestBackup() { 
		System.out.println("Fallback operation called");
		
		return "empty";
	}
}
