package com.tritech.springboot.service.discovery.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TritechSpringBootServiceDiscoveryClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
