package com.tritech.springboot.service.one;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class TritechSpringBootServiceOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(TritechSpringBootServiceOneApplication.class, args);
	}

}
