package com.tritech.springboot.service.two;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class TestController {

	@GetMapping(value="/newtest")
	public String getNewTest(){
	
		return "New test";
	}
}
