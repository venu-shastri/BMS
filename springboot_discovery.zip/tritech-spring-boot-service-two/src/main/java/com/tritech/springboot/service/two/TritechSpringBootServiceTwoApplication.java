package com.tritech.springboot.service.two;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TritechSpringBootServiceTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TritechSpringBootServiceTwoApplication.class, args);
	}

}
