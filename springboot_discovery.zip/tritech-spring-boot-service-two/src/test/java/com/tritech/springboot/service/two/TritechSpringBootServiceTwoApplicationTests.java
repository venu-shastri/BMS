package com.tritech.springboot.service.two;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TritechSpringBootServiceTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
